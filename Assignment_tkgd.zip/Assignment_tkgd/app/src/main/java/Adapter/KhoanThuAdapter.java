package Adapter;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.assignment_tkgd.MainActivity;
import com.example.assignment_tkgd.R;

import java.util.ArrayList;
import java.util.List;

import SQLite.Database;
import model.KhoanChi;
import model.KhoanThu;

public class KhoanThuAdapter extends BaseAdapter {

    Context context;
    List<KhoanThu>khoanThuList;
    public KhoanThuAdapter(Context context, ArrayList<KhoanThu>khoanThuList){
        this.context=context;
        this.khoanThuList=khoanThuList;
    }

    @Override
    public int getCount() {
        return khoanThuList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }
    public class ViewHolder{
        TextView txtkhoanthu;
        ImageView khoanthusua,khoanthusoa;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        final ViewHolder holder;
        if(view == null){
            holder =new ViewHolder();
            LayoutInflater inflater =(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view =inflater.inflate(R.layout.list_item_khoan_thu,null);
            holder.txtkhoanthu =(TextView)view.findViewById(R.id.txt_khoanthu);
            holder.khoanthusua =(ImageView)view.findViewById(R.id.khoanthusua);
            holder.khoanthusoa =(ImageView)view.findViewById(R.id.khoanthuxoa);
            view.setTag(holder);
        }
        else {
            holder=(ViewHolder)view.getTag();
        }
        final KhoanThu kt =khoanThuList.get(i);
        holder.txtkhoanthu.setText(kt.getKhoanthu());

        holder.khoanthusua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(context);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.dialog_sua);

                final EditText edtsua = (EditText) dialog.findViewById(R.id.edt_sua);
                Button btnsua = (Button) dialog.findViewById(R.id.btn_sua);
                edtsua.setText(kt.getKhoanthu());

                btnsua.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int b = kt.getId();
                        String a = edtsua.getText().toString();
                        if (a.isEmpty()) {
                            Toast.makeText(context,
                                    "Vui lòng không để trống khoản thu",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Database database = new Database(context);
                            database.SendData("UPDATE THU SET KHOANTHU ='"
                                    + a + "' WHERE IDTHU ='" + b + "' ");
                            Toast.makeText(context,
                                    "Bạn đã thay đổi thông tin thành công",
                                    Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                            ((MainActivity) context).recreate();
                        }
                    }
                });
                dialog.show();
            }
        });
        holder.khoanthusoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog1 = new Dialog(context);
                dialog1.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog1.setContentView(R.layout.dialog_xoa);
                Button btnchapnhanxoa = (Button)dialog1.findViewById(R.id.btn_chapnhanxoa);
                Button btnhuyxoabo = (Button)dialog1.findViewById(R.id.btn_huyboxoa);

                btnchapnhanxoa.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog1.dismiss();
                    }
                });
                btnchapnhanxoa.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Database database = new Database(context);
                        int a = kt.getId();
                        database.SendData("DELETE FROM THU WWHERE IDTHU ="+a+"");
                        dialog1.dismiss();
                        Toast.makeText(context,
                                "Xóa thông tin thu thành công",
                                Toast.LENGTH_SHORT).show();
                        ((MainActivity)context).recreate();
                    }
                });
                dialog1.show();
            }
        });
        return view;
    }
}
