package Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.assignment_tkgd.R;

import java.util.ArrayList;
import java.util.List;

import model.ThongKeChi;

public class ThongKeChiAdapter extends BaseAdapter {
    Context context;
    int layout;
    List<ThongKeChi>list;

    public ThongKeChiAdapter(Context context, int layout, ArrayList<ThongKeChi>list){
        this.context=context;
        this.layout=layout;
        this.list=list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }
    private class ViewHolder{
        TextView txt_ngaythang,txt_khoanchi,txtloaichi;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if (view == null){
            holder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            view =inflater.inflate(layout,null);

            holder.txt_ngaythang =(TextView)view.findViewById(R.id.txt_ngaythang1);
            holder.txt_khoanchi =(TextView)view.findViewById(R.id.txtkhoanchi);
            holder.txtloaichi =(TextView)view.findViewById(R.id.txtloaichi );

            view.setTag(holder);
        }
        else {
            holder = (ViewHolder) view.getTag();
        }
        ThongKeChi tkc =list.get(i);
        holder.txt_ngaythang.setText(tkc.getNgaythang());
        holder.txtloaichi.setText(tkc.getLoaichi());

        return view;
    }
}
