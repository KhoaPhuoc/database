package Adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class PagerAdapter2 extends FragmentStatePagerAdapter {
    public PagerAdapter2(FragmentManager fm){
        super(fm);
    }

    /**
     * Return the Fragment associated with a specified position.
     *
     * @param i
     */
    @NonNull
    @Override
    public Fragment getItem(int i) {
        if (i == 0){
            return  new FMKC();
        }
        else if (i == 1){
            return new FMLC();
        }
        else{
            return null;
        }
    }

    /**
     * Return the number of views available.
     */
    @Override
    public int getCount() {
        return 2;
    }
    public CharSequence getPageTitle(int position){
        switch (position){
            case 0:
                return "Khoản chi";
            case 1:
                return "Loại chi";
        }
        return null;
    }

    private class FMLC extends Fragment {
    }

    private class FMKC extends Fragment {
    }
}
