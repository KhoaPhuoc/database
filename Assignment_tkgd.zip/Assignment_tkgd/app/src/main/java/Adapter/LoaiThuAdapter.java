package Adapter;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.assignment_tkgd.MainActivity;
import com.example.assignment_tkgd.R;

import java.util.ArrayList;
import java.util.List;

import SQLite.Database;
import model.LoaiChi;
import model.LoaiThu;

public class LoaiThuAdapter extends BaseAdapter {
    Context context;
    int layout;
    List<LoaiThu> loaiThuList;
    public LoaiThuAdapter(Context context, int layout, ArrayList<LoaiThu> loaiThuList){
        this.context=context;
        this.layout=layout;
        this.loaiThuList=loaiThuList;
    }

    @Override
    public int getCount() {
        return loaiThuList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }
    private class ViewHolder{
        TextView txtloaithu;
        ImageView loaithusua;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
      ViewHolder holder = new ViewHolder();
        if(view == null){
            holder =new ViewHolder();
            LayoutInflater inflater =(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view =inflater.inflate(layout,null);
            holder.txtloaithu =(TextView)view.findViewById(R.id.txt_loaithu);
            holder.loaithusua =(ImageView)view.findViewById(R.id.loaithusua);
            view.setTag(holder);
        }
        else {
            holder=(ViewHolder)view.getTag();
        }
        final LoaiThu lt =loaiThuList.get(i);
        holder.txtloaithu.setText(lt.getLoaithu());

        holder.loaithusua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(context);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.dialog_sua);

                final EditText edtsua = (EditText) dialog.findViewById(R.id.edt_sua);
                edtsua.setText((lt.getLoaithu()));
                Button btnsua = (Button) dialog.findViewById(R.id.btn_sua);
                btnsua.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int b = lt.getIdthu();
                        String a = edtsua.getText().toString();
                        if (a.isEmpty()) {
                            Toast.makeText(context,
                                    "Vui lòng không để trống loại thu",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Database database = new Database(context);
                            database.SendData("UPDATE THU SET LOAITHU ='"
                                    + a + "' WHERE IDTHU ='" + b + "' ");
                            Toast.makeText(context,
                                    "Bạn đã thay đổi thông tin thành công",
                                    Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                            ((MainActivity) context).recreate();
                        }
                    }
                });
                dialog.show();
            }
        });
        return view;
    }

}
