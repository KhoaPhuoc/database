package Adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class PagerAdapter1 extends FragmentStatePagerAdapter {
    public PagerAdapter1(FragmentManager fm){
        super(fm);
    }

    /**
     * Return the Fragment associated with a specified position.
     *
     * @param i
     */
    @NonNull
    @Override
    public Fragment getItem(int i) {
        if (i == 0){
            return  new FMKT();
        }
        else if (i == 1){
            return new FMLT();
        }
        else{
        return null;
        }
    }

    /**
     * Return the number of views available.
     */
    @Override
    public int getCount() {
        return 2;
    }
    public CharSequence getPageTitle(int position){
        switch (position){
            case 0:
                return "Khoản thu";
            case 1:
                return "Loại thu";
        }
        return null;
    }

    private class FMLT extends Fragment {
    }

    private class FMKT extends Fragment {
    }
}