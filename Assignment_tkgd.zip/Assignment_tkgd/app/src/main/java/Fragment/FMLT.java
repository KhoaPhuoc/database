package Fragment;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.example.assignment_tkgd.R;

import java.util.ArrayList;


import Adapter.LoaiThuAdapter;
import SQLite.Database;
import model.LoaiThu;

public class FMLT extends Fragment {
    public FMLT(){

    }
    private View rootView;
    ArrayList<LoaiThu> list;
    ListView lv_loaithu;
    Database database;
    LoaiThuAdapter adaper;

    public View onCreateView(LayoutInflater inflater,
                             ViewGroup viewGroup, Bundle saveInstanceState){
        rootView=inflater.inflate(R.layout.fragment_loai_thu,viewGroup,false);
        initView();
        return rootView;
    }

    private void initView() {
        database = new Database(getActivity());
        lv_loaithu =rootView.findViewById(R.id.lv_loaithu);
        list =new ArrayList<>();
        LoaiThuAdapter adapter = new LoaiThuAdapter(getActivity(), R.layout.list_item_loai_thu, list);
        Cursor dataloaithu =database.GetData("SELECT * FROM THU ");
        list.clear();
        while (dataloaithu.moveToNext()){
            String a =dataloaithu.getString(2);
            int b =dataloaithu.getInt(3);
            list.add((new LoaiThu(a,b)));
        }
        adapter.notifyDataSetChanged();
        lv_loaithu.setAdapter(adaper);
    }
}
