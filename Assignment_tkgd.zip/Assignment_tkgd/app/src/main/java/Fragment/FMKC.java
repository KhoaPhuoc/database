package Fragment;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.example.assignment_tkgd.R;

import java.util.ArrayList;

import Adapter.KhoanChiAdapter;
import SQLite.Database;
import model.KhoanChi;

public class FMKC extends Fragment {

    private ListAdapter adaper;

    public void onStart(){super.onStart();}
public FMKC(){

}
private View rootView;
ArrayList<KhoanChi>list;
ListView lv_khoanchi;
Database database;

public View onCreateView(LayoutInflater inflater,
                         ViewGroup container, Bundle saveInstanceState){
    rootView=inflater.inflate(R.layout.flagment_khoan_chi,container,false);
    initView();
    return rootView;
}

    private void initView() {
    database = new Database(getActivity());
    lv_khoanchi =rootView.findViewById(R.id.lv_khoanchi);
    list =new ArrayList<>();
        KhoanChiAdapter adapter = new KhoanChiAdapter(getActivity(), list, R.layout.list_item_khoan_chi);
        Cursor datakhoanchi =database.GetData("SELECT * FROM CHI ");
        list.clear();
        while (datakhoanchi.moveToNext()){
            String a =datakhoanchi.getString(1);
            int b =datakhoanchi.getInt(3);
            list.add((new KhoanChi(a,b)));
        }
        adapter.notifyDataSetChanged();
        lv_khoanchi.setAdapter(adaper);
    }
}


