package Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.example.assignment_tkgd.R;

import java.util.ArrayList;

import Adapter.KhoanThuAdapter;
import SQLite.Database;
import model.KhoanThu;

public class FMKT extends Fragment {
    private FMKT(){

    }
    ListView lv_khoanthu;
    ArrayList<KhoanThu>list;
    Database database;
    KhoanThuAdapter adapter;
    private View rootview;
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup viewGroup, Bundle saveInstanceState){
        rootview = inflater.inflate(R.layout.fragment_khoan_thu,viewGroup,false);
        initView();
        return rootview;
    }

    private void initView() {
    }

}
