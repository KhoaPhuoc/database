package com.example.assignment_tkgd;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import Adapter.PagerAdapter1;
import Adapter.PagerAdapter2;

public class flagment3 extends Fragment {
    public flagment3(){

    }
    private View rootView;
    TabLayout tl;
    PagerAdapter2 adapter;
    ViewPager viewPager;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup viewGroup, Bundle bundle){
        rootView =inflater.inflate(R.layout.flagment2,viewGroup,false);
        initView();
        return rootView;
    }

    private void initView() {
        adapter = new PagerAdapter2(getActivity().getSupportFragmentManager());
        tl = rootView.findViewById(R.id.tab_layout2);
        viewPager = rootView.findViewById(R.id.view_paper2);
        viewPager.setAdapter(adapter);
        tl.setupWithViewPager(viewPager);
    }

}
