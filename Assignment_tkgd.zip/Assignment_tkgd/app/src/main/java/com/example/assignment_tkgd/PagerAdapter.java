package com.example.assignment_tkgd;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class PagerAdapter extends FragmentStatePagerAdapter {
    public  PagerAdapter(FragmentManager fm){
        super(fm);
    }

    /**
     * Return the Fragment associated with a specified position.
     *
     * @param position
     */
    @NonNull
    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
            switch (position){
                case 0:
                    fragment = new flagment2();
                case 1:
                    fragment = new flagment3();
                case 2:
                    fragment= new flagment1();
                case 3:
                    fragment = new GioiThieuActivity();
                    break;
            }
            return fragment;
    }

    /**
     * Return the number of views available.
     */
    @Override
    public int getCount() {
        return 4;
    }
}
