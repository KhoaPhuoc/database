package com.example.assignment_tkgd;

import android.app.Activity;

public class activity_main extends Activity {
}
