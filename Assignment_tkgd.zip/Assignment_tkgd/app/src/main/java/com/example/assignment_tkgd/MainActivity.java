package com.example.assignment_tkgd;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import android.app.Dialog;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import SQLite.Database;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener{
    ViewPager pager;
    Database database;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        pager = (ViewPager)findViewById(R.id.view_paper);
        PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager());
        pager.setAdapter(adapter);

        FloatingActionButton floatingActionButton =(FloatingActionButton) findViewById(R.id.fab);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                database = new Database(MainActivity.this);
                if (pager.getCurrentItem() == 0){
                    final Dialog dialog  = new Dialog(MainActivity.this);
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setContentView(R.layout.dialog_thu);

                    final EditText edt_khoanthu = (EditText)dialog.findViewById(R.id.edtkhoanthu);
                    final EditText edt_loaithu = (EditText)dialog.findViewById(R.id.edtloaithu);
                    Button btnvaothu = (Button)dialog.findViewById(R.id.btnvaothu);
                    btnvaothu.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String a = edt_khoanthu.getText().toString();
                            String b =edt_loaithu.getText().toString();
                            String c =
                                    new SimpleDateFormat("dd-MM-yyyy").format(Calendar.getInstance().getTime());
                            if (a.isEmpty()|| b.isEmpty()){
                                Toast.makeText(MainActivity.this,"Vui lòng không để trống",
                                        Toast.LENGTH_SHORT).show();
                            }
                            else {
                                database.SendData("INSERT INTO THU VALUES ('"+ c +"','"+a+"','"+b+"', NULL)");
                                PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager());
                                pager.setAdapter(adapter);
                                pager.setCurrentItem(2);
                                Toast.makeText(MainActivity.this,"Thêm dữ liệu thu thành công",
                                        Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            }

                        }
                    });
                    dialog.show();
                }
                else if (pager.getCurrentItem() == 1){
                    final Dialog dialog  = new Dialog(MainActivity.this);
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setContentView(R.layout.dialog_chi);

                    final EditText edt_khoanchi = (EditText)dialog.findViewById(R.id.edtkhoanchi);
                    final EditText edtloaichi = (EditText)dialog.findViewById(R.id.edtloaichi);
                    Button btnvaochi = (Button)dialog.findViewById(R.id.btnvaochi);
                    btnvaochi.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String a = new SimpleDateFormat("dd-MM-yyyy").format(Calendar.getInstance().getTime());
                            String b = edtloaichi.getText().toString();
                            String c = edtloaichi.getText().toString();

                            if (a.isEmpty()|| b.isEmpty()){
                                Toast.makeText(MainActivity.this,"Vui lòng không để trống",
                                        Toast.LENGTH_SHORT).show();
                            }
                            else {
                                database.SendData("INSERT INTO THU VALUES ('"+ a +"','"+b+"','"+c+"', NULL)");
                                PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager());
                                pager.setAdapter(adapter);
                                pager.setCurrentItem(2);
                                Toast.makeText(MainActivity.this,"Thêm dữ liệu thu thành công",
                                        Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            }

                        }
                    });
                    dialog.show();
                }

            }
        });
        DrawerLayout drawer = (DrawerLayout)findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle;
        toggle = new ActionBarDrawerToggle(this,
                drawer,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView =(NavigationView)findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    private void setSupportActionBar(Toolbar toolbar) {
    }


    /**
     * Called when an item in the navigation menu is selected.
     *
     * @param item The selected item
     * @return true to display the item as the selected item
     */
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_khoanthu){
            PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager());
            pager.setCurrentItem(0);
            pager.setAdapter(adapter);
        }
        if (id == R.id.nav_khoanchi){
            PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager());
            pager.setCurrentItem(1);
            pager.setAdapter(adapter);
        }
        if (id == R.id.nav_thongke){
            PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager());
            pager.setCurrentItem(2);
            pager.setAdapter(adapter);
        }
        if (id == R.id.nav_gioithieu){
            PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager());
            pager.setCurrentItem(3);
            pager.setAdapter(adapter);
        }
        if (id == R.id.nav_thoat){
            finish();
        }
        DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }
}
