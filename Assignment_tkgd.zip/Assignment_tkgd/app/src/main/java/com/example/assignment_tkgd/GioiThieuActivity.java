package com.example.assignment_tkgd;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class GioiThieuActivity extends Fragment {
    private TextView mTextMessage;
    private View rootview;

    public  View onCreateView(LayoutInflater inflater, ViewGroup viewGroup, Bundle bundle){
        rootview =inflater.inflate(R.layout.activity_gioi_thieu,viewGroup,false);
        initView();
        return rootview;
    }

    private void initView() {
        mTextMessage = rootview.findViewById(R.id.message);
        BottomNavigationView navigation = rootview.findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener);
    }
    private  BottomNavigationView.OnNavigationItemSelectedListener onNavigationItemSelectedListener =  new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()){
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    SimpleDateFormat format = new SimpleDateFormat("hh:mm:ss dd-MM-yyy");
                    String a = format.format(Calendar.getInstance().getTime());
                    mTextMessage.setText(a);
                    return true;
                case R.id.navigation_notifications:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }
    };
}
